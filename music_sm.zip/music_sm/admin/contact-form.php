<?php
include 'header.php';
error_reporting(0);
if(isset($_POST['submit'])){
  $e = $_POST['email'];
  $p = $_POST['mobile'];
  $a = $_POST['address'];

  $sql="Update page set Email='$e',Mobile='$p',Page_Description='$a' where Page_Type='Contact'";
  $result = mysqli_query($conn, $sql);
  if($result){
    echo "<script>alert('Contact details Updated Successfully.');</script>";
  }else{
    echo "<script>alert('oops Something went wrong. Please try again');</script>";
  }


}
?>
        <!-- Layout container -->
        <div class="layout-page">
            <nav
            class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar"
          >
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
              <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                <i class="bx bx-menu bx-sm"></i>
              </a>
            </div>

              <!-- Search -->
              <div class="navbar-nav align-items-center">
                <h4 class="card-header fw-bold"><span class="text-muted fw-light">Pages/</span> Contact Details</h4>
              </div>
              <!-- /Search -->
          </nav>
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <!-- Basic Layout & Basic with Icons -->
              <div class="row">
                <!-- Basic with Icons -->
                <div class="col-xxl">
                  <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h5 class="mb-0">Update Contact Details</h5>
                    </div>
                    <div class="card-body">
                    <?php
                     $sql="SELECT * FROM `page` Where Page_Type='Contact'";
                     $result = mysqli_query($conn, $sql);
                     while($row = mysqli_fetch_array($result))  {
                      ?>
                    
                            
                      <form action="" method="post">
                        <div class="row mb-3">
                          
                          <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                              
                              
                            </div>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-icon-default-email">Email</label>
                          <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                              <span class="input-group-text"><i class="bx bx-envelope"></i></span>
                              <input
                                name="email"
                                type="text"
                                id="basic-icon-default-email"
                                class="form-control"
                                value="<?php echo $row['Email'];?>"
                                aria-label="john.doe"
                                aria-describedby="basic-icon-default-email2"
                              />
                             </div>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 form-label" for="basic-icon-default-phone">Phone No</label>
                          <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-phone2" class="input-group-text"
                                ><i class="bx bx-phone"></i
                              ></span>
                              <input
                                name="mobile"
                                type="text"
                                id="basic-icon-default-phone"
                                class="form-control phone-mask"
                                value="<?php echo $row['Mobile'];?>"
                                aria-label="658 799 8941"
                                aria-describedby="basic-icon-default-phone2"
                              />
                            </div>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 form-label" for="basic-icon-default-message">Address</label>
                          <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-message2" class="input-group-text"
                                ><i class="bx bx-comment"></i
                              ></span>
                              <input
                                name="address"
                                type="text"
                                id="basic-icon-default-phone"
                                class="form-control phone-mask"
                                value="<?php echo $row['Page_Description'];?>"
                                aria-label="658 799 8941"
                                aria-describedby="basic-icon-default-phone2"
                              />
                            </div>
                          </div>
                        </div>
                        <div class="row justify-content-end">
                          <div class="col-sm-10">
                            <button type="submit" name="submit" class="btn btn-primary">Update</button>
                            <a class="btn btn-link ml-2 w-40 " href="index.php">Cancel</a>
                          </div>
                        </div>
                      </form>
                      <?php
                     }
                     ?>
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->
            <?php
include 'footer.php';
?>

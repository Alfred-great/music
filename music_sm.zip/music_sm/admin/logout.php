<?php
session_start();


$_SESSION['ulogin'] = null;


header("location: login.php");

?>